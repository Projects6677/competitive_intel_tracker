# diff_detector.py - FINAL, VERIFIED CORRECT VERSION (Fixing Syntax and Logic)

import difflib
import sqlite3

DATABASE_PATH = 'ci_tracker.db'

def get_latest_snapshots(url):
    """
    Retrieves the two most recent content snapshots for a given URL.
    Returns strings of the raw content.
    """
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    
    # Fetching the two latest snapshots, ordered by timestamp (DESC)
    results = cursor.execute(
        "SELECT raw_content FROM snapshots WHERE url=? ORDER BY timestamp DESC LIMIT 2",
        (url,)
    ).fetchall()
    
    conn.close()
    
    if len(results) < 2:
        return None, None  # Need at least two snapshots to compare
    
    # Extract content strings from tuples
    current_content_text = results[0][0]   # latest snapshot
    previous_content_text = results[1][0]  # previous snapshot
    
    return previous_content_text, current_content_text


def find_added_content(competitor_name, previous_content, current_content):
    """
    Compares two text blobs and returns only the newly added lines 
    (or lines involved in a replacement).
    """
    
    previous_lines = previous_content.splitlines()
    current_lines = current_content.splitlines()

    differ = difflib.SequenceMatcher(None, previous_lines, current_lines)
    
    # ✅ FIX: initialize properly
    added_lines = []
    
    for tag, i1, i2, j1, j2 in differ.get_opcodes():
        if tag == 'insert':
            # Lines added in the current version
            for line in current_lines[j1:j2]:
                added_lines.append(f"+ {line.strip()}")
        elif tag == 'replace':
            # Lines modified/replaced
            for line in current_lines[j1:j2]:
                added_lines.append(f"* {line.strip()}")

    raw_diff_text = "\n".join(added_lines).strip()
    
    if raw_diff_text:
        print(f"[{competitor_name}] 💥 Found {len(added_lines)} significant difference line(s).")
    else:
        print(f"[{competitor_name}] 💯 No textual differences found after cleaning.")
        
    return raw_diff_text
