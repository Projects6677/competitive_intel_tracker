from scraper.scraper import save_snapshot, close_db
from diff.diff_detector import get_new_lines
import sqlite3

# List of competitor URLs
urls = [
    'https://example.com',
    'https://example2.com'
]

# Connect to SQLite DB
conn = sqlite3.connect('database/competitors.db')
cursor = conn.cursor()

for url in urls:
    # Scrape latest content and save snapshot
    new_content = save_snapshot(url)
    
    # Fetch previous snapshot
    cursor.execute('SELECT content FROM snapshots WHERE url=? ORDER BY date_scraped DESC LIMIT 2', (url,))
    rows = cursor.fetchall()
    if len(rows) == 2:
        old_content = rows[1][0]
    else:
        old_content = ''

    # Detect new lines
    new_lines = get_new_lines(old_content, new_content)
    print(f'--- New content for {url} ---')
    if new_lines:
        for line in new_lines:
            print(line)
    else:
        print('No new content detected.')

# Close DB connection
close_db()
