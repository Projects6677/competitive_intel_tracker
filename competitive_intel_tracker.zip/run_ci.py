# run_ci.py - FINAL: Complete Orchestrator with DB Linkage

import time
import os
import json
from dotenv import load_dotenv
from twilio.rest import Client
import sqlite3 # Re-add sqlite3 for a cleaner structure

# Load environment variables
load_dotenv() 

# --- Import Modules ---
from db_setup import init_db, DATABASE_PATH
from scraper import scrape_and_store 
from diff_detector import get_latest_snapshots, find_added_content 
from intelligence_schema import CompetitorUpdate
from llm_intelligence import analyze_diff_with_gemini
from slack_notifier import send_slack_notification
from datetime import datetime

# --- Configuration (Pulled from .env) ---
COMPETITOR_URL = os.getenv("COMPETITOR_URL")
COMPETITOR_NAME = os.getenv("COMPETITOR_NAME")

# Twilio
TWILIO_ACCOUNT_SID = os.getenv("TWILIO_ACCOUNT_SID")
TWILIO_AUTH_TOKEN = os.getenv("TWILIO_AUTH_TOKEN")
TWILIO_PHONE_NUMBER = os.getenv("TWILIO_PHONE_NUMBER")       
TEAM_PHONE_NUMBER = os.getenv("TEAM_PHONE_NUMBER")       


# --- Twilio SMS Function ---
def send_sms_alert(message_text):
    if not TWILIO_ACCOUNT_SID:
        print("ERROR: Twilio credentials not set. Skipping SMS alert.")
        return
        
    client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)
    try:
        message = client.messages.create(
            body=message_text,
            from_=TWILIO_PHONE_NUMBER,
            to=TEAM_PHONE_NUMBER
        )
        print(f"✅ SMS sent. SID: {message.sid}")
    except Exception as e:
        print(f"❌ Failed to send SMS: {e}")


# --- Data Persistence Function ---
def log_intelligence(conn, snapshot_id, url, name, update_data: CompetitorUpdate):
    """Inserts the LLM's structured analysis into the intelligence_log table."""
    cursor = conn.cursor()
    
    # Store summary_digest as a JSON string
    summary_json = json.dumps(update_data.summary_digest)
    
    cursor.execute("""
        INSERT INTO intelligence_log (snapshot_id, url, competitor_name, timestamp, primary_category, competitive_impact_score, is_critical, summary_digest)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        snapshot_id, # This is the critical linkage
        url,
        name,
        datetime.now().isoformat(),
        update_data.primary_category,
        update_data.competitive_impact_score,
        update_data.is_critical,
        summary_json
    ))
    conn.commit()
    print(f"[{name}] 💾 LLM Analysis logged to database (Snapshot ID: {snapshot_id}).")


# --- Process Competitor ---
def process_competitor(name, url, db_conn):
    print(f"\n--- Starting Full CI Cycle for: {name} ---")

    # 1. Scrape and store snapshot (NOW RETURNS snapshot_id)
    new_content, timestamp, snapshot_id = scrape_and_store(url, name, db_conn)

    if new_content is None:
        print(f"[{name}] Skipping analysis: No *new* snapshot created.")
        return

    # 2. Change detection
    prev_content, curr_content = get_latest_snapshots(url)
    
    # Ensure both old and new content exists for diffing
    if prev_content and curr_content:
        raw_diff_text = find_added_content(name, prev_content, curr_content)
        
        if raw_diff_text:
            print(f"[{name}] Raw diff lines found. Moving to LLM analysis.")

            # 3. LLM Analysis
            llm_analysis = analyze_diff_with_gemini(raw_diff_text)

            if llm_analysis:
                # 4. Store LLM Result (USING THE REAL snapshot_id)
                log_intelligence(db_conn, snapshot_id, url, name, llm_analysis)

                # 5. Slack notification
                send_slack_notification(name, llm_analysis)

                # 6. Twilio SMS notification
                if llm_analysis.is_critical:
                    sms_body = f"🔥 CRITICAL: {name} {llm_analysis.primary_category}! Score {llm_analysis.competitive_impact_score}/5. Summary: {llm_analysis.summary_digest[0]}"
                else:
                    sms_body = f"📊 UPDATE: {name} minor change ({llm_analysis.primary_category}). Check Slack/Dashboard."
                
                send_sms_alert(sms_body)
                print(f"[{name}] Alerts sent successfully.")
            else:
                print(f"[{name}] LLM analysis failed.")
        else:
            print(f"[{name}] No actionable textual diff found.")
    else:
        print(f"[{name}] Two snapshots required for diffing. Skipping LLM analysis.")


# --- Main Orchestrator ---
def main_orchestrator():
    db_conn = init_db()

    print(f"\n=======================================================")
    print(f"  RUNNING CI PIPELINE (Slack + Twilio SMS + Gemini LLM)")
    print(f"=======================================================")

    try:
        process_competitor(COMPETITOR_NAME, COMPETITOR_URL, db_conn)
    except Exception as e:
        print(f"FATAL ERROR during CI processing: {e}")

    db_conn.close()
    print("\n--- CI PIPELINE EXECUTION FINISHED ---")


if __name__ == '__main__':
    main_orchestrator()