# day1_orchestrator.py

# --- Import modules and functions ---
# In a real setup, ensure these are imported from the files above.
from db_setup import init_db, DATABASE_PATH
from scraper import scrape_and_store
from diff_detector import get_latest_snapshots, find_added_content

# --- Configuration ---
COMPETITOR_URL = "http://books.toscrape.com/catalogue/a-light-in-the-attic_1000/index.html" 
COMPETITOR_NAME = "Example Competitor"

def run_day1_pipeline():
    """Executes the full Scrape -> Store -> Diff detection pipeline."""
    
    db_conn = init_db()
    
    # --- STEP 1: Scrape and Store ---
    new_content, timestamp = scrape_and_store(COMPETITOR_URL, COMPETITOR_NAME, db_conn)
    
    db_conn.close() # Close connection after write operations

    if new_content is None:
        print("\n--- DAY 1 PIPELINE COMPLETE ---")
        print("Scrape successful. No new snapshot needed, or error occurred.")
        return

    # --- STEP 2: Change Detection (Diffing) ---
    print("\n--- Starting Change Detection ---")
    
    previous_content, current_content = get_latest_snapshots(COMPETITOR_URL)
    
    if previous_content and current_content:
        raw_diff = find_added_content(COMPETITOR_NAME, previous_content, current_content)
        
        if raw_diff:
            print("\n--- RAW DIFF OUTPUT (Ready for LLM in Day 2) ---")
            print(raw_diff)
            print("-------------------------------------------------")
        else:
            print("No actionable diff was generated.")
    else:
        print("Requires a second scrape run to compare changes.")

    print("\n--- DAY 1 PIPELINE COMPLETE ---")
    print("Run this script again after making a textual change on the website to see the diff.")


if __name__ == '__main__':
    run_day1_pipeline()