# llm_intelligence.py - FINAL: Enhanced Few-Shot Examples

from google import genai
import json
import os
from dotenv import load_dotenv

load_dotenv()
from intelligence_schema import CompetitorUpdate

# --- Few-Shot Examples for Consistency ---
FEW_SHOT_EXAMPLES = [
    {
        # Example 1: Pricing/Critical
        "input": "+ We have officially launched our new 'Pro Tier' subscription. \n+ Pricing table now lists the Pro Tier at $49/month.",
        "output": json.dumps({
            "primary_category": "Pricing",
            "competitive_impact_score": 5,
            "is_critical": True,
            "summary_digest": ["Launched new 'Pro Tier' subscription at $49/month.", "Requires immediate competitive review of value proposition."]
        }, indent=2)
    },
    {
        # Example 2: Feature/High Impact
        "input": "+ Integrated new feature X into the dashboard. \n+ Updated documentation page for new API endpoints.",
        "output": json.dumps({
            "primary_category": "Feature",
            "competitive_impact_score": 4,
            "is_critical": True,
            "summary_digest": ["Integrated new feature X for all users.", "Launched updated documentation for API endpoints."]
        }, indent=2)
    },
    {
        # Example 3: Marketing/PR/Low Impact
        "input": "+ Launched new blog post about 'The Future of AI'. \n+ Updated hero image for holidays.",
        "output": json.dumps({
            "primary_category": "Marketing/PR",
            "competitive_impact_score": 2,
            "is_critical": False,
            "summary_digest": ["Published new content discussing industry trends.", "Minor visual update to the main website banner."]
        }, indent=2)
    }
]

def build_few_shot_prompt(raw_diff_text):
    """Constructs the full prompt including role, CoT instruction, and examples."""
    
    SYSTEM_PROMPT = (
        "You are a Senior Competitive Intelligence Analyst. Your task is to analyze raw text diffs "
        "from a competitor's website and transform them into structured, actionable intelligence. "
        "The final output MUST strictly adhere to the provided JSON schema."
    )
    
    example_text = ""
    for ex in FEW_SHOT_EXAMPLES:
        # NOTE: Using the structure from the original file for formatting the examples.
        example_text += (
            f"\n--- START EXAMPLE ---\n"
            f"INPUT DIFF: {ex['input'].strip()}\n"
            f"DESIRED JSON OUTPUT: {ex['output'].strip()}\n"
            f"--- END EXAMPLE ---\n"
        )
    
    final_prompt = (
        f"{SYSTEM_PROMPT}\n\n"
        f"--- FEW-SHOT EXAMPLES ---{example_text}\n"
        f"--- YOUR TASK ---\n"
        f"INPUT DIFF:\n{raw_diff_text}\n\n"
        f"DESIRED JSON OUTPUT:"
    )
    return final_prompt


def analyze_diff_with_gemini(raw_diff_text):
    """Connects to Gemini API and requests structured output."""
    # NOTE: Using os.getenv() for the API Key as per the original file structure.
    GEMINI_API_KEY = os.getenv('GEMINI_API_KEY')
    if not GEMINI_API_KEY:
        print("ERROR: GEMINI_API_KEY not found. Cannot run LLM analysis.")
        return None
        
    client = genai.Client(api_key=GEMINI_API_KEY)
    full_prompt = build_few_shot_prompt(raw_diff_text)
    
    try:
        print("💡 Sending diff to Gemini for structured analysis...")
        response = client.models.generate_content(
            model="gemini-2.5-flash",
            contents=full_prompt,
            config={
                "response_mime_type": "application/json",
                "response_schema": CompetitorUpdate,
            },
        )
        print("✅ Analysis complete.")
        return response.parsed

    except Exception as e:
        print(f"❌ Gemini API Error: {e}")
        return None