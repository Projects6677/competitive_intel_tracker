# scheduler.py - FINAL: CI Agent Automated Scheduler

import time
import schedule
import os
import json
import sqlite3
from datetime import datetime, timedelta
from dotenv import load_dotenv

load_dotenv()

# --- Configuration from .env ---
DATABASE_PATH = 'ci_tracker.db'

# NOTE: run_ci.py is now fully refactored to use os.getenv() for its internal config.
# We import the core functions to run the pipeline.
from run_ci import main_orchestrator, send_sms_alert 


def get_daily_digest_updates():
    """Queries the database for all NON-CRITICAL updates from the last 24 hours."""
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    
    time_24h_ago = (datetime.now() - timedelta(hours=24)).isoformat()
    
    # Query for non-critical (is_critical = 0) updates
    results = cursor.execute("""
        SELECT competitor_name, primary_category, competitive_impact_score, summary_digest
        FROM intelligence_log
        WHERE timestamp >= ? AND is_critical = 0
        ORDER BY competitive_impact_score DESC, timestamp ASC
    """, (time_24h_ago,)).fetchall()
    
    conn.close()
    return results

def send_consolidated_digest():
    """Formats and sends a single Twilio SMS digest of non-critical updates."""
    updates = get_daily_digest_updates()
    
    if not updates:
        print("📰 Daily Digest: No non-critical updates found in the last 24 hours.")
        return
    
    total_count = len(updates)
    
    # Concatenate the first bullet point of the highest-impact updates
    digest_summary = []
    for name, category, score, summary_json in updates[:3]: # Limit to top 3 for SMS length
        try:
            summary_list = json.loads(summary_json)
            first_bullet = summary_list[0] if summary_list else "No summary available"
            digest_summary.append(f"[{category} {score}/5] {name}: {first_bullet}")
        except json.JSONDecodeError:
            digest_summary.append(f"[{category}] {name}: Summary error.")

    full_message = (
        f"--- Daily CI Digest ({datetime.now().strftime('%Y-%m-%d')}) ---\n"
        f"Total Updates: {total_count}. Top 3 Non-Critical Moves:\n"
        + "\n".join(digest_summary)
    )
    
    print(f"📰 Sending consolidated digest with {total_count} items...")
    send_sms_alert(full_message)

def run_all_pending():
    """Wrapper function to run schedule.run_pending()"""
    schedule.run_pending()
    
if __name__ == '__main__':
    # 1. Schedule the core CI pipeline to check for changes frequently
    schedule.every(1).hour.do(main_orchestrator) 
    print("✅ Core CI Pipeline scheduled to run hourly.")

    # 2. Schedule the daily consolidated digest (for non-critical updates)
    schedule.every().day.at("09:00").do(send_consolidated_digest)
    print("✅ Daily Twilio Digest scheduled for 09:00 AM.")
    
    print("Starting CI Agent. Press Ctrl+C to stop.")
    
    # Main Agent Loop
    while True:
        run_all_pending()
        time.sleep(60) # check every minute for pending jobs