# db_setup.py

import sqlite3

DATABASE_PATH = 'ci_tracker.db'

def init_db():
    """Initializes the SQLite database and sets performance modes."""
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    
    # Apply performance optimizations: WAL and relaxed sync
    cursor.execute("PRAGMA journal_mode=WAL;") 
    cursor.execute("PRAGMA synchronous=NORMAL;")
    
    # The 'snapshots' table stores the competitor history as time-series data
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS snapshots (
        id INTEGER PRIMARY KEY,
        url TEXT NOT NULL,
        timestamp DATETIME NOT NULL,
        content_hash TEXT NOT NULL,
        raw_content TEXT,
        UNIQUE(url, content_hash) 
    );
    """)
    # Add indexes for efficient historical lookups
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_url_ts ON snapshots (url, timestamp DESC);")
    
    # --- NEW: intelligence_log table to store LLM output ---
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS intelligence_log (
        id INTEGER PRIMARY KEY,
        snapshot_id INTEGER,
        url TEXT NOT NULL,
        competitor_name TEXT NOT NULL,
        timestamp DATETIME NOT NULL,
        primary_category TEXT,
        competitive_impact_score INTEGER,
        is_critical BOOLEAN,
        summary_digest TEXT, -- Stored as JSON string
        FOREIGN KEY(snapshot_id) REFERENCES snapshots(id)
    );
    """)
    
    conn.commit()
    print(f" Database initialized successfully at {DATABASE_PATH}.")
    return conn

if __name__ == '__main__':
    db_conn = init_db()
    db_conn.close()