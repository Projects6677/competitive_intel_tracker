# scraper.py - FINAL: Returning the snapshot_id

import sqlite3
import hashlib
from datetime import datetime
from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright

DATABASE_PATH = 'ci_tracker.db'

def clean_html(html_content):
    """Surgically cleans HTML to remove noise elements like footers, scripts, ads, etc."""
    soup = BeautifulSoup(html_content, 'html.parser')
    
    # 1. Remove structural noise
    for selector in ['script', 'style', 'footer', 'header', '.ad-container', 'nav', 'noscript']:
        for tag in soup.select(selector):
            tag.decompose() 

    # 2. Simplify wrapper tags
    for selector in ['span', 'div.wrapper']:
        for tag in soup.select(selector):
            if tag.name not in ['body', 'html']:
                tag.unwrap() 

    cleaned_text = soup.get_text(separator=' ', strip=True)
    return cleaned_text

def scrape_and_store(url, competitor_name, conn):
    """Uses Playwright to fetch dynamic content, cleans it, and stores the snapshot."""
    
    print(f"[{competitor_name}] 🔎 Fetching dynamic content...")
    snapshot_id = None # Initialize snapshot_id

    try:
        with sync_playwright() as p:
            browser = p.chromium.launch()
            page = browser.new_page()
            
            page.set_extra_http_headers({
                'User-Agent': 'CI-Tracker/1.0 (Contact: team@hackathon.dev)'
            })
            page.goto(url, wait_until="networkidle")
            page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
            page.wait_for_timeout(2000)  # stabilization pause

            html_content = page.content()
            browser.close()

        cleaned_text = clean_html(html_content)
        current_hash = hashlib.sha256(cleaned_text.encode('utf-8')).hexdigest()
        timestamp = datetime.now().isoformat()

        cursor = conn.cursor()

        # Ensure snapshot_checks table exists
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS snapshot_checks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            url TEXT NOT NULL,
            checked_at TEXT NOT NULL,
            content_hash TEXT NOT NULL
        )
        """)

        # Fetch the latest snapshot hash
        last_snapshot_tuple = cursor.execute(
            "SELECT content_hash, timestamp FROM snapshots WHERE url=? ORDER BY timestamp DESC LIMIT 1", 
            (url,)
        ).fetchone()

        if last_snapshot_tuple:
            previous_hash, previous_timestamp = last_snapshot_tuple
            if previous_hash == current_hash:
                # Content unchanged: log the check for audit purposes
                cursor.execute(
                    "INSERT INTO snapshot_checks (url, checked_at, content_hash) VALUES (?, ?, ?)",
                    (url, timestamp, current_hash)
                )
                conn.commit()
                print(f"[{competitor_name}] ✅ No change detected. Logged check at {timestamp}.")
                return None, timestamp, None # Return None for snapshot_id

        # Store the new snapshot if content changed or no previous snapshot exists
        cursor.execute(
            "INSERT INTO snapshots (url, timestamp, content_hash, raw_content) VALUES (?,?,?,?)",
            (url, timestamp, current_hash, cleaned_text)
        )
        # --- NEW: Retrieve the ID of the last inserted row ---
        snapshot_id = cursor.lastrowid
        conn.commit()
        
        print(f"[{competitor_name}] 💾 New snapshot stored (ID: {snapshot_id}). Hash: {current_hash[:8]}...")
        
        # --- RETURN THE NEW SNAPSHOT ID ---
        return cleaned_text, timestamp, snapshot_id

    except Exception as e:
        print(f"[{competitor_name}] ❌ Error during scrape: {e}")
        return None, None, None