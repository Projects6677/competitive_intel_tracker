# slack_notifier.py

import json
import requests
import os
from dotenv import load_dotenv

load_dotenv()
from intelligence_schema import CompetitorUpdate 

SLACK_WEBHOOK_URL = os.environ.get("SLACK_WEBHOOK_URL")

def send_slack_notification(competitor_name, update_data: CompetitorUpdate):
    """Sends a formatted alert message to a Slack channel using a webhook."""
    if not SLACK_WEBHOOK_URL:
        print(f"[{competitor_name}] ERROR: SLACK_WEBHOOK_URL not configured. Skipping Slack alert.")
        return

    summary_list = "\n".join([f"• {s}" for s in update_data.summary_digest])
    
    emoji = "🔴 CRITICAL ALERT" if update_data.is_critical else "✨ New Update"
    
    message = {
        "text": f"{emoji} | {competitor_name} - Competitive Update Detected ({update_data.primary_category})",
        "attachments": [
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": f"*Summary of Changes:*\n{summary_list}"
                }
            },
            {
                "type": "divider"
            }
        ]
    }

    try:
        response = requests.post(SLACK_WEBHOOK_URL, json=message)
        response.raise_for_status()
        print(f"[{competitor_name}] ✅ Slack notification sent.")
    except requests.exceptions.RequestException as e:
        print(f"[{competitor_name}] ❌ Failed to send Slack notification: {e}")
