# intelligence_schema.py

from pydantic import BaseModel, Field

class CompetitorUpdate(BaseModel):
    """Schema for the structured competitive intelligence output. [11]"""
    
    primary_category: str = Field(..., description="Categorize as one of: Feature, Pricing, Marketing/PR, Blog/Content, Technical.")
    competitive_impact_score: int = Field(..., description="Score the importance from 1 (minor fix) to 5 (major launch or price change).")
    is_critical: bool = Field(..., description="True if this change is high-impact (score 4 or 5) and requires immediate team review.")
    summary_digest: list[str] = Field(..., description="A list of 3-4 concise bullet points summarizing the key changes (max 120 characters per point).")