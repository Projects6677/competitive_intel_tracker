# day2_orchestrator.py - FINAL DAY 2 PIPELINE

import time
from datetime import datetime
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv() 

# --- WARNING: MOCKING DAY 1 FUNCTIONS FOR SIMPLE TESTING ---
# In your final hackathon submission, replace these stubs with actual imports 
# from db_setup, scraper, and diff_detector files.

# Mocking the required classes and functions for testing the LLM/Alerting flow
class CompetitorUpdate: # Simple mock to prevent NameError
    pass 
def init_db(): print("DB Initialized.")
def scrape_and_store(url, name, conn): 
    # Simulate a change being detected and a new snapshot created
    if not os.path.exists("MOCK_DIFF_TRIGGER"):
        with open("MOCK_DIFF_TRIGGER", "w") as f: f.write("Initial")
        return None, None # Skip first run
    return "New Content Detected", datetime.now().isoformat()

def get_latest_snapshots(url):
    # Mocking: Return content that will generate the diff
    return "Old product description. Version 1.0", "New feature description. Version 2.0"

def find_added_content(name, prev, curr):
    # This mock RAW DIFF output is CRITICAL (Pricing & Feature)
    return """
+ We have officially launched our new 'Pro Tier' subscription.
+ Pro Tier now includes unlimited AI processing.
+ A dedicated 'What's New' section was added to the navigation bar.
- Previous marketing text about 'beta features' was removed.
+ Pricing table now lists the Pro Tier at $49/month.
"""
# --- END MOCKING ---

# Actual Day 2 Imports (assuming your files are in the same folder):
from llm_intelligence import analyze_diff_with_gemini
from slack_notifier import send_slack_notification

# --- Configuration ---
COMPETITOR_URL = "http://books.toscrape.com/catalogue/a-light-in-the-attic_1000/index.html" 
COMPETITOR_NAME = "Atlas Competitor Inc."


def process_competitor(name, url):
    """Executes the full CI pipeline: Scrape -> Diff -> LLM -> Alert."""
    
    db_conn = None # Placeholder for database connection

    # 1. Scrape and Store Snapshot (Day 1)
    new_content, timestamp = scrape_and_store(url, name, db_conn)
    
    if new_content is None:
        print(f"[{name}] Skipping analysis: No *new* snapshot created.")
        return

    # 2. Change Detection (Day 1)
    prev_content, curr_content = get_latest_snapshots(url)
    
    if prev_content and curr_content:
        raw_diff_text = find_added_content(name, prev_content, curr_content)

        if raw_diff_text:
            # 3. LLM Summarization and Categorization (Day 2 CORE)
            llm_analysis = analyze_diff_with_gemini(raw_diff_text)
            
            if llm_analysis:
                # 4. Immediate Alerting (Day 2)
                print(f"\n--- LLM ANALYSIS RESULT ---")
                print(f"[{name}] Score: {llm_analysis.competitive_impact_score}/5 | Critical: {llm_analysis.is_critical} | Category: {llm_analysis.primary_category}")
                print(f"[{name}] Summary: {llm_analysis.summary_digest}")
                print("---------------------------")
                
                # Send the high-priority alert
                send_slack_notification(name, llm_analysis) 
                
            else:
                print(f"[{name}] LLM analysis failed.")
        else:
            print(f"[{name}] No actionable textual diff found.")
    
def main_orchestrator():
    print(f"\n=======================================================")
    print(f"  DAY 2: INTELLIGENCE & SLACK ALERTING MVP")
    print(f"=======================================================")

    process_competitor(COMPETITOR_NAME, COMPETITOR_URL)
    
    print("\n--- DAY 2 PIPELINE COMPLETE ---")
    print("Next: Implement Email Digest and Streamlit Dashboard (Day 3).")

if __name__ == '__main__':
    main_orchestrator()