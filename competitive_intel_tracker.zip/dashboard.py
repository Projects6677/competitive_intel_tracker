# dashboard.py - FINAL: CONNECTED TO LIVE DB

import streamlit as st
import pandas as pd
import plotly.express as px
import sqlite3
import json
from datetime import datetime, timedelta

DATABASE_PATH = 'ci_tracker.db'

# --- 1. Live Data Retrieval ---
def get_live_intelligence_data():
    """Retrieves live competitive intelligence data from the intelligence_log table."""
    conn = sqlite3.connect(DATABASE_PATH)
    
    # Query the intelligence_log table
    query = """
    SELECT 
        competitor_name, 
        timestamp, 
        primary_category, 
        competitive_impact_score, 
        summary_digest
    FROM intelligence_log
    ORDER BY timestamp DESC
    """
    
    df = pd.read_sql_query(query, conn)
    conn.close()
    
    if df.empty:
        # Return an empty DataFrame with the expected columns if no data is found
        return pd.DataFrame(columns=['competitor', 'timestamp', 'category', 'impact_score', 'summary', 'date'])

    # Rename columns to match the visualization logic
    df.rename(columns={
        'competitor_name': 'competitor',
        'primary_category': 'category',
        'competitive_impact_score': 'impact_score',
        'summary_digest': 'summary_json'
    }, inplace=True)

    # Process timestamp and summary
    df['timestamp'] = pd.to_datetime(df['timestamp'])
    df['date'] = df['timestamp'].dt.date
    
    # Convert JSON string summary back to a list (for display in raw feed)
    df['summary'] = df['summary_json'].apply(lambda x: json.loads(x) if x else [])
    
    return df

# --- 2. Dashboard Layout ---
st.set_page_config(layout="wide", page_title="CI Tracker Dashboard")

st.title("🎯 Competitive Intelligence Activity Dashboard")
st.markdown("Visualizing the *tempo* of competitor activity and strategic moves.")

df_updates = get_live_intelligence_data()

if df_updates.empty:
    st.info("No competitive intelligence data has been logged yet. Run the CI pipeline to generate data.")
else:
    # --- 3. Visualization: Competitor Activity Heatmap ---
    st.subheader("1. Activity Calendar Heatmap (Based on Aggregate Impact)")
    st.markdown("The color intensity of each day reflects the total *Competitive Impact Score*.")

    df_daily_activity = df_updates.groupby('date')['impact_score'].sum().reset_index()

    # Ensure a full calendar view for better visualization (copied logic from mock version)
    today = datetime.now().date()
    start_date = df_updates['date'].min() - timedelta(days=7) if not df_updates['date'].empty else today - timedelta(days=7)
    end_date = today + timedelta(days=7)
    date_range = pd.date_range(start_date, end_date, freq='D').date
    df_calendar = pd.DataFrame({'date': date_range})
    df_calendar = pd.merge(df_calendar, df_daily_activity, on='date', how='left').fillna(0)


    fig_heatmap = px.scatter(
        df_calendar,
        x="date",
        y=[1] * len(df_calendar), 
        size="impact_score", 
        color="impact_score", 
        color_continuous_scale=px.colors.sequential.Sunset,
        hover_data={'date': True, 'impact_score': True},
        labels={'impact_score': 'Total Daily Impact Score'},
        title="Daily Scrape Activity Intensity"
    )
    fig_heatmap.update_layout(
        yaxis={'visible': False, 'showticklabels': False}, 
        xaxis_title="Time",
        height=200
    )

    st.plotly_chart(fig_heatmap, use_container_width=True)


    # --- 4. Visualization: Strategic Timeline (Gantt Concept) ---
    st.subheader("2. Strategic Timeline: Critical Events & Roadmap")
    st.markdown("Tracking high-impact events (Features & Pricing), providing a derived competitor roadmap.")

    # Filter for Feature and Pricing only
    df_strategic = df_updates[df_updates['category'].isin(['Feature', 'Pricing'])]

    fig_timeline = px.scatter(
        df_strategic,
        x='timestamp',
        y='competitor',
        color='category',
        size='impact_score',
        hover_data=['summary', 'impact_score'],
        title="Critical Strategic Events Timeline",
        height=400
    )

    fig_timeline.update_layout(yaxis_title="Competitor")
    st.plotly_chart(fig_timeline, use_container_width=True)

    # --- 5. Raw Data View ---
    st.subheader("Raw Intelligence Feed")
    # Drop the summary_json column before display
    st.dataframe(df_updates.drop(columns=['summary_json']).sort_values(by='timestamp', ascending=False), use_container_width=True)