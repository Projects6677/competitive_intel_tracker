# sendgrid_notifier.py

import os
import requests
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail, Email, To, Content
from intelligence_schema import CompetitorUpdate 
from datetime import datetime
from dotenv import load_dotenv

load_dotenv()

# --- Configuration (Pulled from.env) ---
SENDGRID_API_KEY = os.environ.get('SENDGRID_API_KEY')
FROM_EMAIL = "ci-tracker@yourhackathonapp.com" 
TO_EMAIL = "team-digest@yourcompany.com"

# --- SENDGRID DIGEST ---
def send_daily_digest(update_list):
    """
    Sends a formatted HTML email digest of competitive updates using SendGrid. 
    update_list is a list of tuples: [(competitor_name, CompetitorUpdate object),...]
    """
    if not SENDGRID_API_KEY:
        print("ERROR: SENDGRID_API_KEY not found. Skipping email digest.")
        return

    print(f"📧 Preparing to send {len(update_list)} items in daily digest...")
    
    html_content_parts =
    
    for name, update in update_list:
        summary_bullets = "<ul>" + "".join(
            [f"<li>{s}</li>" for s in update.summary_digest]
        ) + "</ul>"
        
        header_style = "color: red; font-size: 16px;" if update.is_critical else "color: #007BFF; font-size: 16px;"
        
        html_content_parts.append(f"""
            <h3 style="{header_style}">{name} - {update.primary_category} (Score: {update.competitive_impact_score}/5)</h3>
            {summary_bullets}
            <hr>
        """)

    full_html_content = (
        f"<h2>Daily Competitive Intelligence Digest ({datetime.now().strftime('%Y-%m-%d')})</h2>"
        f"This digest contains {len(update_list)} non-critical updates from the last 24 hours."
        f"{''.join(html_content_parts)}"
    )

    try:
        message = Mail(
            from_email=Email(FROM_EMAIL),
            to_emails=To(TO_EMAIL),
            subject=f"CI Daily Digest: {len(update_list)} Updates",
            html_content=Content("text/html", full_html_content)
        )
        
        sg = SendGridAPIClient(SENDGRID_API_KEY)
        response = sg.client.mail.send.post(request_body=message.get())
        
        print(f"✅ SendGrid Status: {response.status_code}. Email digest dispatched.")
        
    except Exception as e:
        print(f"❌ SendGrid Error: {e}")